/********************************************
 * recover.c
 * 
 * CS50 AP
 * Recover
 * 
 * Recovers "lost" JPGs
 * 
 * ******************************************/

int main(int argc, char* argv[])
{
    // TODO
    
    return 0;
}
